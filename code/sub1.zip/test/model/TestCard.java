package model;

/**
 * tests
 */
public class TestCard {

}
