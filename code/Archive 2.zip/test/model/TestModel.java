package model;
import java.util.ArrayList;
import java.util.List;
import model.card.Card;
import model.card.GameCard;
import org.junit.*;


public class TestModel {
  @Before
  public void setUp() {

  }
}
