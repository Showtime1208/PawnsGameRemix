package controller;


/**
 * Controller Interface for the game. Not necessary yet.
 */
public interface Controller {

}
