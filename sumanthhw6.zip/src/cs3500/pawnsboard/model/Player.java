package cs3500.pawnsboard.model;

/**
 * The two players in a game of PawnsBoard.
 */
public enum Player {
  RED, BLUE
}
