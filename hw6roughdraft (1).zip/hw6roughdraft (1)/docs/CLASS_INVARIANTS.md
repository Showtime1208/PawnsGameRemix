/**
 * Class Invariants for PawnsGameModel:
 *
 * 1. The board dimensions must always satisfy:
 *    - `rows > 0`
 *    - `cols >= 3` and must be **odd** (ensures a center column for fair gameplay).
 *
 * 2. Each player must always:
 *    - Have a **unique deck** that is identical to the opponent’s (per game rules).
 *    - Maintain a **hand size** up to the specified max (`handSize`) if cards remain in the deck.
 *    - Only play cards they legally can (checked with `isValidPlacement`).
 *
 * 3. A player **must not place a card** unless:
 *    - The placement is legal (`isValidPlacement` returns `true`).
 *    - They own enough pawns at the target location.
 *
 * 4. The game ends **only if**:
 *    - **Both** players consecutively pass (`lastPlayerPassed == true` and the next player also passes).
 *    - **Neither** player has a legal move left (`hasValidMove(redPlayer) == false && hasValidMove(bluePlayer) == false`).
 *
 * 5. Turn order always alternates correctly:
 *    - `currentPlayer` is always valid (either `redPlayer` or `bluePlayer`).
 *    - `switchTurn()` properly alternates between players.
 *
 * 6. The board always starts with:
 *    - Pawns placed in the **first and last columns** (`1r` for RED, `1b` for BLUE).
 *    - No cards placed initially.
 */
