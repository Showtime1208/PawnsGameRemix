Design Document for Pawns Board Model

1. Overview

This document outlines the design of the model for the Pawns Board game, a two-player strategy game derived from Queen’s Blood. The model is responsible for maintaining the game state, enforcing the rules, and providing mechanisms for game interactions such as placing cards, tracking influence, and determining the winner. The model does not handle visualization or user input directly but provides an interface for the view and controller components to interact with the game logic.

2. Design Goals

Encapsulation: The model should expose only necessary methods while keeping internal details hidden.

Extensibility: Future additions, such as AI players or additional influence mechanics, should be accommodated.

Modularity: The model is designed with clear separations of concerns, making it easy to modify or extend individual components.

Testability: The model should be easy to unit test independently of the view and controller.

3. Key Design Decisions

3.1 Board Representation

The board is stored as a 2D array of BoardCell objects.

This allows efficient indexing and manipulation of board positions.

3.2 Influence Handling

The influenceGrid of a card is applied relative to the placed position.

3.3 Scoring System

The board tracks row-scores dynamically.

The GameModel iterates over rows at the end of the game to determine the winner.

3.4 Deck Management

Decks are loaded from files to allow easy customization.

The DeckLoader ensures that decks are valid before the game starts.


5. Assumptions and Invariants

The board must always have an odd number of columns.

Each player has a deck with at most two copies of each card.

Influence cannot exceed board boundaries.

A maximum of three pawns can exist on any cell at a time.

