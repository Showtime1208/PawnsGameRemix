README - QueensBlood Game

Overview

This codebase implements the Pawns Board game, a two-player strategy game inspired by Queen’s Blood. The primary goal of this codebase is to model and simulate the game, ensuring adherence to the game's rules, influence mechanics, and scoring system. The design prioritizes modularity, encapsulation, and extensibility, allowing for potential expansions such as AI players, additional influence mechanics, and graphical user interfaces.

High-Level Assumptions

Players take turns placing cards or passing, starting with the Red player.

Each card has a cost, a value score, and an influence pattern that affects adjacent cells.

Influence mechanics follow the game's mirroring rules for Blue's perspective.

The board size must have an odd number of columns and a positive number of rows.

The game ends when both players pass their turns consecutively.

A textual-based interface is provided in this implementation; graphical extensions may be added later.

Quick Start

To run the Pawns Board game, use the PawnsBoardMain class as the entry point. The game will load deck configurations, initialize the board, and begin play with a textual interface.

Key Components

1. Game Model (Drives the control-flow)

GameModel: Interface defining game logic.

PawnsGameModel: Implements game rules, turn management, and scoring.

Board: Manages grid-based interactions.

BoardCell: Represents individual board locations.

GamePlayer: Manages player attributes, hands, and actions.

2. Card Mechanics

Card: Represents a playable game card with cost, value, and influence pattern.

GameCard: Specialized subclass applying influence on board.

InfluenceType: Enum defining different influence types.

3. File Handling

DeckLoader: Reads deck configuration files and validates deck data.

4. Game Entry Point

PawnsBoardMain: Main class to execute a textual-based simulation of the game.

Key Subcomponents

Each key component has its own set of classes that work together to implement specific aspects of the game:

Board and Cell Management

Board: Holds a 2D array of BoardCell objects.

BoardCell: Can store pawns, cards, or remain empty.

Player System

GamePlayer: Each player has a hand, a deck, and a color (Red or Blue).

Ownership: Enum tracking pawn ownership.

Gameplay Logic

PawnsGameModel: Enforces rules such as turn-taking, placement legality, and scoring.

GameModel: Defines interfaces for any possible variations in game mechanics.


## Changes for Part 2

To comply with MVC architecture and support view/strategy development, we refactored the `GameModel` interface:

- Introduced `ReadonlyGameModel` to isolate observation logic.
- `GameModel` now extends `ReadonlyGameModel` and contains only mutator methods like `startGame`, `placeCard`, and `passTurn`.
- Added new methods to `ReadonlyGameModel` to support:
    - Row/total scoring
    - Access to hand and board contents
    - Legal move checking
    - Game-over and winner queries

This allows our view and strategies to safely observe the model without the ability to mutate it.
